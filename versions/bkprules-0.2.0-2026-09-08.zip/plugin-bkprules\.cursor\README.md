# .cursor

Pasta local de rules, commands e hooks do Cursor.
Gerenciada / observada pelo BKPrules para backup automatico.
